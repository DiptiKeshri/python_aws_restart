amino = "malwmrllpllallalwgpdpaaafvnqhlcgshlvealylvcgergffytpktrreaedlqvgqvelgggpgagslqplalegslqkrgiveqcctsicslyqlenycn"
print(len(amino))
print(amino[0:24])
print(amino[24:54])
print(amino[54:89])
print(amino[89:110])



file = open("/home/ec2-user/environment/lsinsulin-seq-clean.txt", "r")
lsinsulin = file.read()
print('Number of characters in text file lsinsulin:', len(lsinsulin))
