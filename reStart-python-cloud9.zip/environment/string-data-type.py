myString = "This is a string."
print(myString)
print(type(myString))
print(myString + " is of the data type " + str(type(myString)))


firstString = "water"
secondString = "fall"
thridString = firstString + secondString
print(thridString)

name = input("What is your name? Maria ")
print(name)

color = input("What is your favorite color? blue ")
animal = input("What is your favorite animal? dog ")

print("{}, you like a {} {}!".format("Maria","blue","dog"))

