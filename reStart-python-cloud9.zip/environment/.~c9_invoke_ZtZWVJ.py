userReply = input("Do you need to ship a package? Enter yes or no")
if userReply == "yes":
    print("we can help you ship that package!")
else:
    print("Please come back when you need to ship a package. Thank you.")

userReply = input("Would you like to buy stamps, buy am envelope, or make a copy? (Enter stamps, e")    