print("hello,world")
print("hello world")